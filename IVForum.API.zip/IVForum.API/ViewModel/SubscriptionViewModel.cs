﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IVForum.API.ViewModel
{
    public class SubscriptionViewModel
    {
        public string ForumId { get; set; }
        public string ProjectId { get; set; }
    }
}
