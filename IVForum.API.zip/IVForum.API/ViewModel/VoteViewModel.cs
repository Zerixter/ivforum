﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IVForum.API.ViewModel
{
    public class VoteViewModel
    {
        public string ProjectId { get; set; }
        public string Value { get; set; }
    }
}
